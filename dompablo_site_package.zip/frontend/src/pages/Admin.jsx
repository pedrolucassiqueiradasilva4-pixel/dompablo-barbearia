import React from 'react';
export default function Admin(){
  return (
    <div style={{background:'#000', color:'#fff', minHeight:'100vh', padding:40}}>
      <h2>Painel Admin (placeholder)</h2>
      <p>Use as rotas de API para login e gerenciamento. Admin padrão: admin / 123456</p>
    </div>
  )
}
