import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Agendar(){
  const [barbers, setBarbers] = useState([]);
  const [form, setForm] = useState({ client_name:'', client_phone:'', barber_id:'', datetime:'' });
  const api = import.meta.env.VITE_API_URL || 'http://localhost:4000';

  useEffect(()=>{
    axios.get(`${api}/api/public/barbers`).then(r=>setBarbers(r.data)).catch(()=>{});
  },[]);

  async function handleSubmit(e){
    e.preventDefault();
    try{
      await axios.post(`${api}/api/bookings`, form);
      alert('Agendamento confirmado!');
      window.location.href = '/';
    }catch(err){
      alert('Erro ao agendar. Verifique os dados e tente novamente.');
    }
  }

  return (
    <div style={{background:'#000', color:'#fff', minHeight:'100vh', padding:40}}>
      <h2>Agende seu horário - Barbearia Dom Pablo</h2>
      <form onSubmit={handleSubmit} style={{display:'flex',flexDirection:'column',gap:10,maxWidth:420}}>
        <input required placeholder="Nome" value={form.client_name} onChange={e=>setForm({...form, client_name:e.target.value})} />
        <input required placeholder="Telefone (ex: +5511999999999)" value={form.client_phone} onChange={e=>setForm({...form, client_phone:e.target.value})} />
        <select required value={form.barber_id} onChange={e=>setForm({...form, barber_id:e.target.value})}>
          <option value="">Escolha um barbeiro</option>
          {barbers.map(b=> <option key={b.id} value={b.id}>{b.name}</option>)}
        </select>
        <input required type="datetime-local" value={form.datetime} onChange={e=>setForm({...form, datetime:e.target.value})} />
        <button type="submit">Confirmar agendamento</button>
      </form>
      <p style={{marginTop:20}}>Dúvidas: <a href="https://wa.me/5531973139868">WhatsApp</a></p>
    </div>
  )
}
