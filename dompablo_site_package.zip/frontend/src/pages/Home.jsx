import React from 'react';
export default function Home(){
  return (
    <div style={{background:'#000', color:'#fff', minHeight:'100vh', padding:40}}>
      <h1>Barbearia Dom Pablo</h1>
      <p>Bem-vindo! <a href="/agendar">Agende aqui</a> ou fale no WhatsApp: <a href="https://wa.me/5531973139868">(31) 97313-9868</a></p>
    </div>
  )
}
