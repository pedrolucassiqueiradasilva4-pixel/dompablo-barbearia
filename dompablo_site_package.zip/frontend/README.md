Barbearia Dom Pablo — Frontend (React + Vite)

Instruções:
1. Instale dependências: npm install
2. Crie variável de ambiente VITE_API_URL apontando para o backend (ex: https://seu-backend.onrender.com)
3. Rode: npm run dev
