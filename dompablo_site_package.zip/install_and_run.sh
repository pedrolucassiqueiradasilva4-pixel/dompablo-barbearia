#!/bin/bash
echo "Instalando backend..."
cd backend || exit 1
npm install
echo "Rodando backend em background (node server.js)..."
nohup node server.js > ../backend.log 2>&1 &
cd ..
echo "Instalando frontend..."
cd frontend || exit 1
npm install
echo "Frontend: rode 'npm run dev' para testar localmente"
echo "Pronto. Backend rodando em background. Veja logs em backend.log"
