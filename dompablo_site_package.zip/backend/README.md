Barbearia Dom Pablo — Backend (Node.js)

Instruções rápidas:
1. Instale dependências: npm install
2. Copie .env.example para .env e ajuste as variáveis.
3. Rode: node server.js

Admin padrão: admin / 123456
