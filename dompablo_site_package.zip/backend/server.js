require('dotenv').config();
const express = require('express');
const cors = require('cors');
const db = require('./db');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const twilio = require('twilio');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'dompablo123';

let twClient = null;
const TWILIO_WHATSAPP_FROM = process.env.TWILIO_WHATSAPP_FROM || '';

if(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN){
  twClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
}

function authMiddleware(req, res, next){
  const token = req.headers.authorization?.split(' ')[1];
  if(!token) return res.status(401).send({error:'no token'});
  try{
    const data = jwt.verify(token, JWT_SECRET);
    req.user = data;
    next();
  }catch(e){
    return res.status(401).send({error:'invalid token'});
  }
}

(function createAdminIfMissing(){
  const row = db.prepare('SELECT * FROM admins LIMIT 1').get();
  if(!row){
    const id = uuidv4();
    const username = process.env.ADMIN_USER || 'admin';
    const pass = process.env.ADMIN_PASS || '123456';
    const hash = bcrypt.hashSync(pass, 10);
    db.prepare('INSERT INTO admins (id, username, password_hash) VALUES (?, ?, ?)').run(id, username, hash);
    console.log('Admin criado:', username);
  }
})();

(function seedBarbers(){
  const existing = db.prepare('SELECT COUNT(*) as c FROM barbers').get();
  if(!existing || existing.c === 0){
    const names = ['Pablo','Rafa','Luiz','Gabriel'];
    const insert = db.prepare('INSERT INTO barbers (id, name) VALUES (?, ?)');
    names.forEach(n => insert.run(uuidv4(), n));
    console.log('Barbeiros iniciais criados');
  }
})();

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const admin = db.prepare('SELECT * FROM admins WHERE username = ?').get(username);
  if(!admin) return res.status(401).send({error:'Usuário não encontrado'});
  const ok = bcrypt.compareSync(password, admin.password_hash);
  if(!ok) return res.status(401).send({error:'Senha inválida'});
  const token = jwt.sign({ id: admin.id, username: admin.username }, JWT_SECRET, { expiresIn: '8h' });
  res.send({ token });
});

app.get('/api/barbers', authMiddleware, (req, res) => {
  const rows = db.prepare('SELECT * FROM barbers').all();
  res.send(rows);
});

app.post('/api/barbers', authMiddleware, (req, res) => {
  const { name } = req.body;
  const id = uuidv4();
  db.prepare('INSERT INTO barbers (id, name) VALUES (?, ?)').run(id, name);
  res.send({ id, name });
});

app.get('/api/public/barbers', (req, res) => {
  const rows = db.prepare('SELECT * FROM barbers').all();
  res.send(rows);
});

app.post('/api/bookings', (req, res) => {
  const { barber_id, client_name, client_phone, datetime } = req.body;
  if(!client_phone || !client_name || !datetime) return res.status(400).send({ error: 'dados incompletos' });
  const id = uuidv4();
  const created_at = new Date().toISOString();
  db.prepare('INSERT INTO bookings (id, barber_id, client_name, client_phone, datetime, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(id, barber_id, client_name, client_phone, datetime, 'confirmed', created_at);

  if(twClient && TWILIO_WHATSAPP_FROM){
    const to = `whatsapp:${client_phone}`;
    const body = `Barbearia Dom Pablo: Agendamento confirmado para ${client_name} em ${datetime}. Obrigado!`;
    twClient.messages.create({ from: TWILIO_WHATSAPP_FROM, to, body })
      .then(msg => console.log('WhatsApp sent', msg.sid))
      .catch(err => console.error('WhatsApp error', err.message));
  }

  res.send({ id, barber_id, client_name, client_phone, datetime });
});

app.get('/api/bookings', authMiddleware, (req, res) => {
  const rows = db.prepare('SELECT b.*, br.name as barber_name FROM bookings b LEFT JOIN barbers br ON br.id = b.barber_id ORDER BY b.datetime DESC').all();
  res.send(rows);
});

app.post('/api/notify/reminder', authMiddleware, async (req, res) => {
  const { bookingId } = req.body;
  const booking = db.prepare('SELECT * FROM bookings WHERE id = ?').get(bookingId);
  if(!booking) return res.status(404).send({error:'agendamento nao encontrado'});
  if(twClient && TWILIO_WHATSAPP_FROM){
    try{
      const to = `whatsapp:${booking.client_phone}`;
      const body = `Lembrete: você tem agendamento na Barbearia Dom Pablo em ${booking.datetime}.`;
      const msg = await twClient.messages.create({ from: TWILIO_WHATSAPP_FROM, to, body });
      return res.send({ ok: true, sid: msg.sid });
    }catch(e){
      return res.status(500).send({ error: e.message });
    }
  }
  return res.status(400).send({ error: 'Twilio não configurado' });
});

app.listen(PORT, () => console.log(`Server rodando na porta ${PORT}`));
