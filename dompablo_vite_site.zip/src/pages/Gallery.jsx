import React from 'react'

export default function Gallery(){
  return (
    <div className='card'>
      <h2>Galeria</h2>
      <p>Em breve: fotos dos cortes e do espaço.</p>
    </div>
  )
}
